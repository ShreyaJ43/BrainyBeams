// Local Storage Counter
const counterValue = document.getElementById('counterValue');
const incrementBtn = document.getElementById('incrementBtn');
const resetBtn = document.getElementById('resetBtn');

// Check if there's already a counter value saved in localStorage
let counter = localStorage.getItem('counter') ? parseInt(localStorage.getItem('counter')) : 0;
counterValue.innerText = counter;

// Increment Counter Button
incrementBtn.addEventListener('click', () => {
    counter++;
    counterValue.innerText = counter;
    localStorage.setItem('counter', counter); // Save the counter value to localStorage
});

// Reset Counter Button
resetBtn.addEventListener('click', () => {
    counter = 0;
    counterValue.innerText = counter;
    localStorage.setItem('counter', counter); // Reset counter in localStorage
});

// Session Storage for Login Data
const loginForm = document.getElementById('loginForm');
const emailInput = document.getElementById('email');
const passwordInput = document.getElementById('password');
const loginMessage = document.getElementById('loginMessage');

// Check if session storage has data for email and password
window.addEventListener('load', () => {
    const storedEmail = sessionStorage.getItem('email');
    const storedPassword = sessionStorage.getItem('password');
    
    if (storedEmail && storedPassword) {
        loginMessage.innerText = `Email and password stored in session storage.`;
    }
});

// Save email and password to session storage when the form is submitted
loginForm.addEventListener('submit', (event) => {
    event.preventDefault();
    const email = emailInput.value;
    const password = passwordInput.value;

    if (email && password) {
        sessionStorage.setItem('email', email);
        sessionStorage.setItem('password', password);
        loginMessage.innerText = `Login data saved to session storage.`;
    } else {
        loginMessage.innerText = `Please fill in both fields.`;
    }
});

// Clear session storage on page close/reload
window.addEventListener('beforeunload', () => {
    sessionStorage.removeItem('email');
    sessionStorage.removeItem('password');
});
