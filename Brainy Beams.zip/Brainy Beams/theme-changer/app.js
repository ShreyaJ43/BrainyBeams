// Theme Context Management
const themeContext = {
    currentTheme: 'light', // Default theme
    setTheme(theme) {
        this.currentTheme = theme;
        // Apply the theme to the document body
        document.body.className = theme + '-theme';
        // Save the theme to localStorage
        localStorage.setItem('theme', theme);
    },
    init() {
        // Load the theme from localStorage if it exists
        const savedTheme = localStorage.getItem('theme');
        if (savedTheme) {
            this.currentTheme = savedTheme;
        }
        this.setTheme(this.currentTheme);
    },
};

// Initialize the theme from localStorage on page load
themeContext.init();

// Get the theme switcher button
const themeSwitcherBtn = document.getElementById('themeSwitcherBtn');

// Event listener for the theme switcher button
themeSwitcherBtn.addEventListener('click', () => {
    // Toggle between 'light' and 'dark' themes
    const newTheme = themeContext.currentTheme === 'light' ? 'dark' : 'light';
    themeContext.setTheme(newTheme);
});
