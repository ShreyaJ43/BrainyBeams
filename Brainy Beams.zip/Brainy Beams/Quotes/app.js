const quoteText = document.getElementById('quote');
const quoteAuthor = document.getElementById('author');
const generateQuoteBtn = document.getElementById('generateQuoteBtn');
const createPostBtn = document.getElementById('createPostBtn');
const postContent = document.getElementById('postContent');
const postsDiv = document.getElementById('posts');

// API URL for random quotes
const quoteAPI = 'https://api.quotable.io/random';

// Fetch a random quote from the API
async function getRandomQuote() {
    try {
        const response = await fetch(quoteAPI);
        const data = await response.json();
        quoteText.innerHTML = `"${data.content}"`;
        quoteAuthor.innerHTML = `- ${data.author}`;
    } catch (error) {
        quoteText.innerHTML = 'An error occurred while fetching the quote.';
    }
}

// Event listener for the "Get Random Quote" button
generateQuoteBtn.addEventListener('click', getRandomQuote);

// Event listener for the "Create Post" button
createPostBtn.addEventListener('click', () => {
    const currentQuote = `${quoteText.innerHTML} ${quoteAuthor.innerHTML}`;
    postContent.value = currentQuote; // Copy the current quote into the post text area
});

// Function to create a new post
createPostBtn.addEventListener('dblclick', () => {
    const postText = postContent.value.trim();
    if (postText !== '') {
        const newPost = document.createElement('div');
        newPost.classList.add('post');
        newPost.innerText = postText;
        postsDiv.appendChild(newPost);
        postContent.value = ''; // Clear the textarea
    }
});
