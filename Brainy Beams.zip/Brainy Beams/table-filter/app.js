// Get input element
const searchInput = document.getElementById("searchInput");
// Add event listener to the input field
searchInput.addEventListener("keyup", filterTable);

function filterTable() {
    // Get the input value and convert to lowercase
    const filterValue = searchInput.value.toLowerCase();
    // Get the table
    const table = document.getElementById("dataTable");
    // Get all the table rows in the tbody
    const rows = table.getElementsByTagName("tr");

    // Loop through the rows, excluding the header row
    for (let i = 1; i < rows.length; i++) {
        const cells = rows[i].getElementsByTagName("td");
        let rowContainsSearchTerm = false;

        // Loop through the cells in the current row
        for (let j = 0; j < cells.length; j++) {
            const cellText = cells[j].textContent || cells[j].innerText;
            if (cellText.toLowerCase().indexOf(filterValue) > -1) {
                rowContainsSearchTerm = true;
                break;
            }
        }

        // Show or hide the row based on the search term
        rows[i].style.display = rowContainsSearchTerm ? "" : "none";
    }
}
