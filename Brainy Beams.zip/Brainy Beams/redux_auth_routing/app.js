// Redux actions
const LOGIN = 'LOGIN';
const LOGOUT = 'LOGOUT';

// Action creators
const login = () => ({ type: LOGIN });
const logout = () => ({ type: LOGOUT });

// Initial state
const initialState = {
    isAuthenticated: false
};

// Reducer to manage authentication state
function authReducer(state = initialState, action) {
    switch (action.type) {
        case LOGIN:
            return { ...state, isAuthenticated: true };
        case LOGOUT:
            return { ...state, isAuthenticated: false };
        default:
            return state;
    }
}

// Create Redux store
const store = Redux.createStore(authReducer);

// Selectors
const loginBtn = document.getElementById('loginBtn');
const logoutBtn = document.getElementById('logoutBtn');
const contentDiv = document.getElementById('content');

// Function to render routes based on authentication state
function renderRoutes() {
    const state = store.getState();

    if (state.isAuthenticated) {
        loginBtn.style.display = 'none';
        logoutBtn.style.display = 'inline-block';
        contentDiv.innerHTML = '<h3>Welcome, You are logged in!</h3>';
    } else {
        loginBtn.style.display = 'inline-block';
        logoutBtn.style.display = 'none';
        contentDiv.innerHTML = '<h3>Please login to access the app.</h3>';
    }
}

// Subscribe to store updates
store.subscribe(renderRoutes);

// Initial render
renderRoutes();

// Event listeners for login and logout
loginBtn.addEventListener('click', () => {
    store.dispatch(login());
});

logoutBtn.addEventListener('click', () => {
    store.dispatch(logout());
});
